<?php
$servername = "localhost";
$username = "root"; // Thay your_username và your_password phù hợp
$password = "";
$dbname = "auto_bill"; // Thay my_database bằng tên cơ sở dữ liệu của bạn

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Thiết lập chế độ lỗi PDO để thông báo lỗi
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Kết nối thành công";
} catch(PDOException $e) {
    echo "Kết nối thất bại: " . $e->getMessage();
}
?>
